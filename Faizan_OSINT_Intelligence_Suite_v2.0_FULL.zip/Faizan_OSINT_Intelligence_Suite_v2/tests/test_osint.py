from app.osint import phone_lookup, investigate

def test_phone_metadata():
    r = phone_lookup("+923001234567")
    assert "e164" in r
    assert r["e164"] == "+923001234567"

def test_dispatch():
    r = investigate("phone", "+923001234567")
    assert r["input"] == "+923001234567"
