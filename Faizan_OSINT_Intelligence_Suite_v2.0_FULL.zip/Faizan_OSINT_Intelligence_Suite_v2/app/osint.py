import csv, io, json, socket, time
from datetime import datetime, timezone

import requests
import phonenumbers
from phonenumbers import geocoder, carrier, timezone as ptimezone
import dns.resolver

PLATFORMS = {
    "GitHub": "https://github.com/{u}",
    "Reddit": "https://www.reddit.com/user/{u}/",
    "X": "https://x.com/{u}",
    "Instagram": "https://www.instagram.com/{u}/",
    "TikTok": "https://www.tiktok.com/@{u}",
}

def now():
    return datetime.now(timezone.utc).isoformat()

def phone_lookup(value, default_region="PK"):
    result = {"input": value, "timestamp": now()}
    try:
        p = phonenumbers.parse(value, default_region)
        result["valid"] = phonenumbers.is_valid_number(p)
        result["possible"] = phonenumbers.is_possible_number(p)
        result["e164"] = phonenumbers.format_number(p, phonenumbers.PhoneNumberFormat.E164)
        result["international"] = phonenumbers.format_number(p, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
        result["country_code"] = p.country_code
        result["national_number"] = str(p.national_number)
        result["region"] = geocoder.description_for_number(p, "en")
        result["carrier"] = carrier.name_for_number(p, "en")
        result["timezones"] = list(ptimezone.time_zones_for_number(p))
        result["note"] = "Metadata only; this does not reveal live GPS or subscriber identity."
    except Exception as e:
        result["error"] = str(e)
    return result

def ip_lookup(ip):
    result = {"input": ip, "timestamp": now()}
    try:
        r = requests.get(
            f"http://ip-api.com/json/{ip}",
            params={"fields":"status,message,country,countryCode,regionName,city,zip,lat,lon,isp,org,as,query"},
            timeout=8
        )
        data = r.json()
        result["data"] = data
        result["note"] = "IP geolocation is approximate and is not a live device location."
    except Exception as e:
        result["error"] = str(e)
    return result

def domain_lookup(domain):
    result = {"input": domain, "timestamp": now(), "dns": {}}
    for typ in ("A","AAAA","MX","NS","TXT","CNAME"):
        try:
            result["dns"][typ] = sorted({str(x) for x in dns.resolver.resolve(domain, typ, lifetime=4)})
        except Exception:
            result["dns"][typ] = []
    try:
        result["addresses"] = sorted(set(socket.gethostbyname_ex(domain)[2]))
    except Exception:
        result["addresses"] = []
    try:
        import whois
        w = whois.whois(domain)
        result["whois"] = {
            "registrar": w.registrar,
            "creation_date": str(w.creation_date),
            "expiration_date": str(w.expiration_date),
            "name_servers": list(w.name_servers or []),
        }
    except Exception as e:
        result["whois_note"] = f"WHOIS unavailable: {e}"
    return result

def username_lookup(username):
    u = username.strip().lstrip("@")
    result = {"input": u, "timestamp": now(), "profiles": []}
    for name, template in PLATFORMS.items():
        url = template.format(u=u)
        try:
            r = requests.get(url, timeout=7, allow_redirects=True,
                             headers={"User-Agent":"Faizan-OSINT-Research/2.0"})
            result["profiles"].append({
                "platform": name,
                "url": url,
                "http_status": r.status_code,
                "public_page_reachable": 200 <= r.status_code < 400
            })
        except requests.RequestException as e:
            result["profiles"].append({"platform": name, "url": url, "error": str(e)})
    result["note"] = "A reachable profile is only a lead; username reuse does not prove the same person."
    return result

def investigate(kind, value):
    if kind == "phone":
        return phone_lookup(value)
    if kind == "ip":
        return ip_lookup(value)
    if kind == "domain":
        return domain_lookup(value)
    if kind == "username":
        return username_lookup(value)
    raise ValueError("Unsupported investigation type")

def export_csv(records):
    out = io.StringIO()
    rows = []
    for r in records:
        rows.append({
            "timestamp": r.get("timestamp",""),
            "type": r.get("type",""),
            "input": r.get("input",""),
            "result": json.dumps(r.get("result",{}), ensure_ascii=False)
        })
    w = csv.DictWriter(out, fieldnames=["timestamp","type","input","result"])
    w.writeheader(); w.writerows(rows)
    return out.getvalue()
