from flask import Flask, request, jsonify, render_template_string, Response
from .osint import investigate, export_csv, now

app = Flask(__name__)
history = []

HTML = """<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>Faizan™ OSINT Intelligence Suite</title>
<style>
body{font-family:system-ui;background:#0b1020;color:#e8eefc;max-width:1050px;margin:auto;padding:24px}
.card{background:#141b31;border:1px solid #2a3557;border-radius:14px;padding:18px;margin:14px 0}
input,select,button{padding:12px;border-radius:9px;border:1px solid #3a4668;background:#0e1528;color:white}
input{width:55%}button{cursor:pointer}.muted{color:#aeb9d5}.danger{color:#ffcccb}
pre{white-space:pre-wrap;overflow:auto}
</style></head>
<body>
<h1>Faizan™ OSINT Intelligence Suite</h1>
<p class="muted">Evidence-oriented public-source research dashboard.</p>
<div class="card">
<select id="kind"><option value="phone">Phone metadata</option><option value="ip">IP intelligence</option><option value="domain">Domain intelligence</option><option value="username">Username/public profiles</option></select>
<input id="value" placeholder="Enter value">
<button onclick="run()">Investigate</button>
</div>
<div class="card"><b>Important:</b> This tool does not provide live GPS, private-account access, passwords, OTPs, or private telecom records. Verify all leads through lawful procedures.</div>
<div class="card"><h3>Result</h3><pre id="out">No investigation yet.</pre></div>
<div class="card"><button onclick="location='/export.csv'">Export case history CSV</button></div>
<script>
async function run(){
 const kind=document.getElementById('kind').value, value=document.getElementById('value').value.trim();
 if(!value){alert('Enter a value');return}
 const r=await fetch('/api/investigate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind,value})});
 const j=await r.json(); document.getElementById('out').textContent=JSON.stringify(j,null,2);
}
</script>
</body></html>"""

@app.get("/")
def index(): return render_template_string(HTML)

@app.post("/api/investigate")
def api_investigate():
    data=request.get_json(silent=True) or {}
    kind=data.get("kind",""); value=str(data.get("value","")).strip()
    if not value: return jsonify({"error":"value required"}),400
    try:
        result=investigate(kind,value)
        record={"timestamp":now(),"type":kind,"input":value,"result":result}
        history.append(record)
        return jsonify(record)
    except Exception as e:
        return jsonify({"error":str(e)}),400

@app.get("/export.csv")
def export():
    return Response(export_csv(history),mimetype="text/csv",
                    headers={"Content-Disposition":"attachment; filename=case_history.csv"})

if __name__ == "__main__":
    app.run(host="127.0.0.1",port=8000,debug=False)
